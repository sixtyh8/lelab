<?php

$covers = array();
$covers[0]['img'] = '00-annie_brocoli-broco_show_2-fr-2010-front.jpg';
$covers[0]['title'] = '<span class="artist">Annie Brocoli</span><br/>Le Brocoshow 2';

$covers[1]['img'] = '1282405527_1500chris-giannini-if-its-me.jpg';
$covers[1]['title'] = '<span class="artist">Chris Giannini</span><br/>If it\'s me';

$covers[2]['img'] = '16 wishes.jpg';
$covers[2]['title'] = '<span class="artist">16 Wishes (movie)</span><br/>16 Wishes Music From The Hit Movie';

$covers[3]['img'] = '194026-douze-hommes-rapailles-volume-2.jpg';
$covers[3]['title'] = '<span class="artist">variés</span><br/>12 hommes rapailés vol. 2';

$covers[4]['img'] = 'a frame.jpg';
$covers[4]['title'] = '<span class="artist">Surface of Atlantic</span><br/>A Frame Per Season';

$covers[5]['img'] = 'Alexandre Belliard - Des.Fantomes.Des.Etoiles.jpg';
$covers[5]['title'] = '<span class="artist">Alexandre Belliard</span><br/>des fantômes, des étoiles';

$covers[6]['img'] = 'appa.jpg';
$covers[6]['title'] = '<span class="artist">Dominica Merola</span><br/>Appassioanata';

$covers[7]['img'] = 'ariane brunet.jpg';
$covers[7]['title'] = '<span class="artist">Ariane Brunet</span><br/>Le pied dans ma bulle';

$covers[8]['img'] = 'boogie wonderband.jpg';
$covers[8]['title'] = '<span class="artist">Boogie Wonderband</span><br/>Supercool';

$covers[9]['img'] = 'BV3000-TheGarden-HiRez3.jpg';
$covers[9]['title'] = '<span class="artist">Bran Van 3000</span><br/>The Garden';

$covers[10]['img'] = 'CDBuckaloose.jpg';
$covers[10]['title'] = '<span class="artist">Buckaloose</span><br/>The 270 Sessions';

$covers[11]['img'] = 'ce soir 1.jpg';
$covers[11]['title'] = '<span class="artist">variés</span><br/>Ce soir on Danse Vol 1';

$covers[12]['img'] = 'ce soir 2.jpg';
$covers[12]['title'] = '<span class="artist">variés</span><br/>Ce soir on Danse Vol 2';

$covers[13]['img'] = 'ce soir 3.jpg';
$covers[13]['title'] = '<span class="artist">variés</span><br/>Ce soir on Danse Vol 3';

$covers[14]['img'] = 'celine dion.png';
$covers[14]['title'] = '<span class="artist">Céline Dion</span><br/>Taking Chances World Tour LE SPECTACLE';

$covers[15]['img'] = 'alecka.jpg';
$covers[15]['title'] = '<span class="artist">Alecka</span><br/>Alecka';

$covers[16]['img'] = 'christian.jpg';
$covers[16]['title'] = '<span class="artist">Christian-Marc</span><br/>Christian-Marc';

$covers[17]['img'] = 'colocs.jpg';
$covers[17]['title'] = '<span class="artist">Les Colocs</span><br/>La comète (single)';

$covers[18]['img'] = 'diane dufresne.jpg';
$covers[18]['title'] = '<span class="artist">Diane Dufresne</span><br/>Les Grands Succes';

$covers[19]['img'] = 'digi.jpg';
$covers[19]['title'] = '<span class="artist">Philippe Leduc</span><br/>Diginada';

$covers[20]['img'] = 'dixie band.jpg';
$covers[20]['title'] = '<span class="artist">Le Dixieband</span><br/>The 270 Sessions';

$covers[21]['img'] = 'elle_sort_digipack_CD_large.jpg';
$covers[21]['title'] = '<span class="artist">Jeanne Rochette</span><br/>The 270 Sessions';

$covers[22]['img'] = 'eric_belanger.jpg';
$covers[22]['title'] = '<span class="artist">Éric Bélanger</span><br/>A 35 mm du bonheur';

$covers[23]['img'] = 'giorgia.jpg';
$covers[23]['title'] = '<span class="artist">Georgia Fumanti</span><br/>Magnificat';

$covers[24]['img'] = 'husky.jpg';
$covers[24]['title'] = '<span class="artist">Le Husky</span><br/>La fuite';

$covers[25]['img'] = 'il-etait-une-fois-nicole.jpg';
$covers[25]['title'] = '<span class="artist">Nicole Martin</span><br/>Il était une fois… Nicole Martin';

$covers[26]['img'] = 'isabeau.jpg';
$covers[26]['title'] = '<span class="artist">Isabeau et les chercheurs d\'or</span><br/>Isabeau et les chercheurs d\'or';

$covers[27]['img'] = 'jason-lang.jpg';
$covers[27]['title'] = '<span class="artist">Jason Lang</span><br/>Boomerang';

$covers[28]['img'] = 'jazzlab.jpg';
$covers[28]['title'] = '<span class="artist">Jazz lab</span><br/>Octo portraits';

$covers[29]['img'] = 'je_nai_pas_change_digipack_CD_z.jpg';
$covers[29]['title'] = '<span class="artist">Michel Louvain</span><br/>Je n\'ai pas changé';

$covers[30]['img'] = 'alexandre_poulin.jpg';
$covers[30]['title'] = '<span class="artist">Alexandre Poulin</span><br/>Une lumière allumée';

$covers[31]['img'] = 'les_filles_de_caleb_digipack_CD_z.jpg';
$covers[31]['title'] = '<span class="artist">Artistes variés</span><br/>Les filles de Caleb';

$covers[32]['img'] = 'duo_ferland.jpg';
$covers[32]['title'] = '<span class="artist">Artistes variés</span><br/>Bijoux de famille duo Ferland';

$covers[33]['img'] = 'buddy.jpg';
$covers[33]['title'] = '<span class="artist">Buddy McNeil</span><br/>Introducing Once Again';

$covers[34]['img'] = 'caroline_dete.jpg';
$covers[34]['title'] = '<span class="artist">Caroline d\'été</span><br/>Comme un arbre';

$covers[35]['img'] = 'cheryl_nye.jpg';
$covers[35]['title'] = '<span class="artist">Cheryl Nye</span><br/>Eyes of a stranger';

$covers[36]['img'] = 'daniel_casavant.jpg';
$covers[36]['title'] = '<span class="artist">Daniel Casavant</span><br/>Nine at the time';

$covers[37]['img'] = 'ingrid_stpierre.jpg';
$covers[37]['title'] = '<span class="artist">Ingrid St-Pierre</span><br/>Ma petite mam\'zelle de chemin';

$covers[37]['img'] = 'france_damour.jpg';
$covers[37]['title'] = '<span class="artist">France d\'Amour</span><br/>Bubble bath and champagne';

$covers[38]['img'] = 'joce_menard.jpg';
$covers[38]['title'] = '<span class="artist">Joce Ménard</span><br/>Ya des jours';

$covers[39]['img'] = 'julie_b.jpg';
$covers[39]['title'] = '<span class="artist">Julie Bélanger</span><br/>S\'il n\'y avait pas toi';

$covers[40]['img'] = 'karkwa-les-chemins-de-verre-420x420.jpg';
$covers[40]['title'] = '<span class="artist">Karkwa</span><br/>Les chemins de verre';

$covers[41]['img'] = 'keravel_must.jpg';
$covers[41]['title'] = '<span class="artist">Keravel</span><br/>Must';

$covers[42]['img'] = 'volee_castor.jpg';
$covers[42]['title'] = '<span class="artist">La volée de castors</span><br/>Le retour';

$covers[43]['img'] = 'les_chiens.jpg';
$covers[43]['title'] = '<span class="artist">Les chiens</span><br/>Nuit dérobée';

$covers[44]['img'] = 'lulu_hughes.jpg';
$covers[44]['title'] = '<span class="artist">Lulu Hughes</span><br/>Lulu Hughes and the Montreal all city big band';

$covers[45]['img'] = 'lynda_lemay.jpg';
$covers[45]['title'] = '<span class="artist">Lynda Lemay</span><br/>Blessée';

$covers[46]['img'] = 'patrick.jpg';
$covers[46]['title'] = '<span class="artist">Patrick Norman</span><br/>Where I come from';

$covers[47]['img'] = 'pierre_lapointe_seul_au_piano_digipack_CD_large.jpg';
$covers[47]['title'] = '<span class="artist">Pierre Lapointe</span><br/>Seul au piano';

$covers[48]['img'] = 'pierre_lapointe_seul_au_piano_digipack_CD_large.jpg';
$covers[48]['title'] = '<span class="artist">Pierre Lapointe</span><br/>Seul au piano';

$covers[49]['img'] = 'new_angle.jpg';
$covers[49]['title'] = '<span class="artist">Samuel Blais</span><br/>New angle';

$covers[50]['img'] = 'atomes.jpg';
$covers[50]['title'] = '<span class="artist">Martin Léon</span><br/>Les atomes';

$covers[51]['img'] = 'PHL_CD_Slendeur_Misere.jpg';
$covers[51]['title'] = '<span class="artist">Philippe Leduc</span><br/>Splendeur et misère';

$covers[52]['img'] = 'premier_baiser.jpg';
$covers[52]['title'] = '<span class="artist">Marie-Chantal Toupin</span><br/>Premier baiser';

$covers[53]['img'] = 'richarddesjardins.jpg';
$covers[53]['title'] = '<span class="artist">Richard Desjardins</span><br/>Symphonique';

$covers[54]['img'] = 'richardseguin-appalaches-150x150.jpg';
$covers[54]['title'] = '<span class="artist">Richard Séguin</span><br/>Appalaches';

$covers[55]['img'] = 'saometis.jpg';
$covers[55]['title'] = '<span class="artist">saOmetis</span><br/>saOmetis';

$covers[56]['img'] = 'sens_karma.jpg';
$covers[56]['title'] = '<span class="artist">Karma</span><br/>Sens';

$covers[57]['img'] = 'sirpathetik.jpg';
$covers[57]['title'] = '<span class="artist">Sir Pathétik</span><br/>10e round';

$covers[58]['img'] = 'tricot.jpg';
$covers[58]['title'] = '<span class="artist">Tricot machine</span><br/>La prochaine étape';

$covers[59]['img'] = 'yves-savard-album.jpg';
$covers[59]['title'] = '<span class="artist">Yves Savard</span><br/>J\'m\'attendais pas à toi';

$covers[60]['img'] = 'La-caverne.jpg';
$covers[60]['title'] = '<span class="artist">Malajube</span><br/>La caverne';

$covers[61]['img'] = 'jerusalem.jpg';
$covers[61]['title'] = '<span class="artist">Matt Herskowitz</span><br/>Jerusalem trilogy';

$covers[62]['img'] = 'nicole_coktail.jpg';
$covers[62]['title'] = '<span class="artist">Nicole Martin</span><br/>Cocktail de douceur';

$covers[63]['img'] = 'lost.jpg';
$covers[63]['title'] = '<span class="artist">The lost fingers</span><br/>Gypsy Kameleon';

$covers[64]['img'] = 'mariedenisepelletier.jpg';
$covers[64]['title'] = '<span class="artist">Marie Denise Pelletier</span><br/>Marie Denise Pelletier';

$covers[65]['img'] = 'ngabo.jpg';
$covers[65]['title'] = '<span class="artist">Ngabo</span><br/>Ngabo';

$covers[66]['img'] = 'triangle_bermudes.jpg';
$covers[66]['title'] = '<span class="artist">Patrick Michaud</span><br/>Le triangle des Bermudes';

$covers[67]['img'] = 'philippe_b.jpg';
$covers[67]['title'] = '<span class="artist">Philippe B</span><br/>Variation fantômes';

$covers[68]['img'] = 'raby.jpg';
$covers[68]['title'] = '<span class="artist">Raby</span><br/>Un matin sans bruit';

$covers[69]['img'] = 'richard_desjardins_existoire.jpg';
$covers[69]['title'] = '<span class="artist">Richard Desjardins</span><br/>L\'existoire';

$covers[70]['img'] = 'saye1.jpg';
$covers[70]['title'] = '<span class="artist">Saye</span><br/>Contrebande';

$covers[71]['img'] = 'soulkast.jpg';
$covers[71]['title'] = '<span class="artist">Soulkast</span><br/>Honoris Causa';

$covers[72]['img'] = 'blue_seed.jpg';
$covers[72]['title'] = '<span class="artist">The blue seeds</span><br/>Belt of Venus';

$covers[73]['img'] = 'the_ultragirls.jpg';
$covers[73]['title'] = '<span class="artist">The ultragirls</span><br/>Girls will be girls';

?>