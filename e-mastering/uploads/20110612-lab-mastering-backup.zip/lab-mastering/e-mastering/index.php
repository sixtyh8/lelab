<?php
$metaTITLE['fr'] = 'E-Mastering';
$metaTITLE['en'] = 'E-Mastering';
$bodyClass = 'e-mastering';

include '../includes/header.php';
?>

<div class="right-box" id="e-mastering-box">
	<div class="right-box-top"></div>
    <div class="right-box-content">
    	<h2>Manager</h2>
        <form id="e-mastering-upload" action="" method="post">
        	<p><input type="file" name="filename" class="file" /></p>
            <p><input type="submit" value="Start upload" class="submit" /></p>
        </form>
    </div>
    <div class="right-box-bottom"></div>
</div>

<?php
include '../includes/footer.php';
?>