<div id="slider">
	<!--<img src="<?php echo $_conf['path']['base_url']; ?>img/<?php echo $_conf['translation']['lang']; ?>/slider/perfect-touch.jpg" alt="" />-->  
    <div id="slider-lists">
    
    <?php
    	include 'covers.php';
		shuffle($covers);
		$slide = 1;
		$index = 1;
		foreach($covers as $cover){
			if(isOpenTag($index)) echo '<ul id="s'.$slide.'" class="list">';
			echo '<li class="cover"><span class="title">'.$cover['title'].'</span><img src="'.$_conf['path']['base_url'].'img/covers/'.$cover['img'].'"></li>';
			if(isEndTag($index)){
				echo '</ul>';
				$slide++;
			}
			$index++;
		}
		
		function isOpenTag($i){
			if($i == 1 || ($i-1)%5 == 0) return true;
			else return false;
		}
		
		function isEndTag($i){
			if($i%5 == 0) return true;
			else return false;
		}
	?>
    </div>
    <a href="#" id="slider-prev" onclick="startSlide('left');"><img src="<?php echo $_conf['path']['base_url']; ?>img/slider-prev.png" alt="" /></a>
    <a href="#" id="slider-next" onclick="startSlide('right');"><img src="<?php echo $_conf['path']['base_url']; ?>img/slider-next.png" alt="" /></a>
</div>

<script type="text/javascript">var maxSlide = <?php echo $slide; ?></script>
<script type="text/javascript" src="<?php echo $_conf['path']['base_url']; ?>js/slider.js"></script>