<?php
	require_once dirname(dirname((__FILE__))).'/conf/config.php';
	require_once dirname(dirname((__FILE__))).'/lib/'.$_conf['translation']['lang'].'.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lab Mastering | <?php echo $metaTITLE[$_conf['translation']['lang']]; ?></title>
<link type="text/css" rel="stylesheet" href="<?php echo $_conf['path']['base_url']; ?>css/main.css" media="screen" />
<link type="text/css" rel="stylesheet" href="<?php echo $_conf['path']['base_url']; ?>css/slider.css" media="screen" />
<link type="text/css" rel="stylesheet" href="<?php echo $_conf['path']['base_url']; ?>css/print.css" media="print" />
<!--[if IE]>
<link type="text/css" rel="stylesheet" href="<?php echo $_conf['path']['base_url']; ?>css/ie.css" media="screen" />
<![endif]-->
<script type="text/javascript" src="<?php echo $_conf['path']['base_url']; ?>js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo $_conf['path']['base_url']; ?>js/jquery-ui-1.7.3.custom.min.js"></script>
<script type="text/javascript">
(function(){
  // if firefox 3.5+, hide content till load (or 3 seconds) to prevent FOUT
  var d = document, e = d.documentElement, s = d.createElement('style');
  if (e.style.MozTransform === ''){ // gecko 1.9.1 inference
    s.textContent = 'body{visibility:hidden}';
    var r = document.getElementsByTagName('script')[0];
    r.parentNode.insertBefore(s, r);
    function f(){ s.parentNode && s.parentNode.removeChild(s); }
    addEventListener('load',f,false);
    setTimeout(f,3000); 
  }
})();
</script>
</head>

<body class="<?php echo $bodyClass; ?>">

<div id="login-bar">

</div>
<div id="wraper">
<h1><a id="logo" href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>"><img src="<?php echo $_conf['path']['base_url']; ?>img/logo-lab.png" alt="Lab Mastering" title="Lab Mastering" /></a></h1>
<ul id="option-bar">
	<li class="no-border"><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>contact">Book a session</a></li>
	<li><a href="https://www.webcargo.net/webcargo/r.php?w=2140980-0f6XZfpFQ3PX9b6DqU" target="_blank">E-Mastering</a></li>
	<li><a href="<?php echo $_conf['translation']['switch_lang']; ?>"><?php if($_conf['translation']['lang']!='fr') echo 'Français'; else echo 'English'; ?></a></li>
</ul>
<ul id="main-menu">
	<li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>" <?php if($bodyClass == 'home') echo 'class="selected"'?>><?php echo MAIN_MENU_HOME; ?></a></li>
	<li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>studio" <?php if($bodyClass == 'studio') echo 'class="selected"'?>><?php echo MAIN_MENU_STUDIO; ?></a></li>
    <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>engineers" <?php if($bodyClass == 'engineers') echo 'class="selected"'?>><?php echo MAIN_MENU_ENGINEERS; ?></a></li>
    <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>mastering" <?php if($bodyClass == 'mastering') echo 'class="selected"'?>><?php echo MAIN_MENU_MASTERING; ?></a></li>
    <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>lab" <?php if($bodyClass == 'lab') echo 'class="selected"'?>><?php echo MAIN_MENU_LAB; ?></a></li>
    <li class="no-border"><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>contact" <?php if($bodyClass == 'contact') echo 'class="selected"'?>><?php echo MAIN_MENU_CONTACT; ?></a></li>
</ul>
<?php
	if($bodyClass == 'home') include 'slider.php';
	if($bodyClass == 'studio' || $bodyClass == 'contact') include 'view.php';
?>
<div id="content">