<?php
$metaTITLE['fr'] = 'Accueil';
$metaTITLE['en'] = 'Home';
$bodyClass = 'home';

include 'includes/header.php';
?>

<div class="full-box">
	<div class="full-box-top"></div>
    <div class="full-box-content no-background no-minheight" style="padding-bottom:40px;">
    <?php if($_conf['translation']['lang'] == 'en'){ ?>
    	<h2>Welcome to Le lab Mastering</h2>
        <p>Our state of the art mastering facility is known for its commitment to uncompromised audio and full commitment to artists and creativity. Le Lab exhibits a precise and truly transparent monitoring design. A high precision, top quality analog and digital signal path is supported by first line analog to digital conversion.</p>
        <p>The listening environment is comfortable, natural and transparent. This entirely neutral sonic landscape will reveal your mixes without added artefacts, leaving the mastering engineer with a clear aural picture of your mixing needs. Being overall sweetness, or surgical corrections, our environment and carefully selected tools will allow for optimal results leaving a unique aural signature to your project.</p>
    <?php } else { ?>
    	<h2>&Agrave; propos</h2>
        <p></p>
    <?php } ?>
    </div>
    <div class="full-box-bottom"></div>
</div>

<?php
include 'includes/footer.php';
?>