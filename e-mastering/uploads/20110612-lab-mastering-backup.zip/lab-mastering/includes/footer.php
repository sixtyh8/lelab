<div id="footer">
	<div class="full-box">
        <div class="full-box-top"></div>
        <div class="full-box-content no-background no-minheight">
        	<ul id="social-networks">
            	<li><strong>Follow us on</strong></li>
            	<li><a href="http://www.facebook.com/profile.php?id=100001874943692" target="_blank"><img src="<?php echo $_conf['path']['base_url']; ?>img/facebook-icon.png" alt="Facebook" /></a></li>
    			<li><a href="http://twitter.com/#!/LeLabMastering" target="_blank"><img src="<?php echo $_conf['path']['base_url']; ?>img/twitter-icon.png" alt="Twitter" /></a></li>
    			<li><a href="http://www.youtube.com/lelabmastering" target="_blank"><img src="<?php echo $_conf['path']['base_url']; ?>img/youtube-icon.png" alt="YouTube" /></a></li>
            </ul>
        </div>
        <div class="full-box-bottom"></div>
    </div>

	<div id="footer-container">
	<ul id="footer-menu">
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>" <?php if($bodyClass == 'home') echo 'class="selected"'?>><?php echo MAIN_MENU_HOME; ?></a></li>
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>studio" <?php if($bodyClass == 'studio') echo 'class="selected"'?>><?php echo MAIN_MENU_STUDIO; ?></a></li>
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>engineers" <?php if($bodyClass == 'engineers') echo 'class="selected"'?>><?php echo MAIN_MENU_ENGINEERS; ?></a></li>
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>mastering" <?php if($bodyClass == 'mastering') echo 'class="selected"'?>><?php echo MAIN_MENU_MASTERING; ?></a></li>
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>lab" <?php if($bodyClass == 'lab') echo 'class="selected"'?>><?php echo MAIN_MENU_LAB; ?></a></li>
        <li><a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>contact" <?php if($bodyClass == 'contact') echo 'class="selected"'?>><?php echo MAIN_MENU_CONTACT; ?></a></li>
    </ul>
    <a href="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>" id="footer-logo"><img src="<?php echo $_conf['path']['base_url']; ?>img/footer-logo.png" alt="Lab Mastering" title="Lab Mastering" /></a>
    </div>
</div>
<div id="legal"><?php echo LEGAL_TEXT; ?></div>
</div>
</div>
</body>
</html>