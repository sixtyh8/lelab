<?php
$metaTITLE['fr'] = 'E-Mastering';
$metaTITLE['en'] = 'E-Mastering';
$bodyClass = 'e-mastering';

include '../includes/header.php';
?>

<div class="right-box" id="e-mastering-box">
	<div class="right-box-top"></div>
    <div class="right-box-content">
    	<h2>Login</h2>
        <form id="e-mastering-login" action="<?php echo $_conf['path']['base_url'].$_conf['translation']['lang'].'/'; ?>e-mastering/" method="post">
        	<p>
            <label for="login">Login</label>
            <input type="text" maxlength="25" name="login" tabindex="1"  />
            </p>
            <p>
            <label for="password">Password</label>
            <input type="password" maxlength="25" name="password" tabindex="2" />
            </p>
            <p style="text-align:right;"><input type="submit" class="submit" value="Connect" /></p>
        </form>
    </div>
    <div class="right-box-bottom"></div>
</div>

<?php
include '../includes/footer.php';
?>