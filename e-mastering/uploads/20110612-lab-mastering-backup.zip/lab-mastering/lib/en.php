<?php
// login
define('LOGIN_USERNAME', 'Username');
define('LOGIN_PASSWORD', 'Password');

// main menu
define('MAIN_MENU_HOME', 'Home');
define('MAIN_MENU_STUDIO', 'Studio');
define('MAIN_MENU_ENGINEERS', 'Engineers');
define('MAIN_MENU_MASTERING', 'Mastering');
define('MAIN_MENU_LAB', 'Lab');
define('MAIN_MENU_CONTACT', 'Contact');

// colonne de droite
define('RIGHT_COL_ACCESS', 'Got your access?');
define('RIGHT_COL_STAY_CONNECTED', 'Stay Connected!');

// studio titles
define('STUDIO_H2', 'Equipment');
define('STUDIO_MONITOR', 'Monitor');
define('STUDIO_FURNITURE', 'Furniture');
define('STUDIO_TRANSPORT', 'Transport');
define('STUDIO_PROCESSOR', 'Analog Processor');
define('DIGITAL_PROCESSOR', 'Digital Processor');
define('STUDIO_POWER', 'Power');
define('STUDIO_ROOM', 'Room');
define('STUDIO_CONVERTER', 'Converter');
define('STUDIO_DAW', 'Daw');

// ing�nieurs titles
define('ENGINEER_CHIEF_MASTERING', 'Chief Mastering Engineer');
define('ENGINEER_MASTERING', 'Mastering Engineer');

// contact
define('CONTACT_OPENING', 'Opening Hours');
define('CONTACT_LATE', 'Late Hours');
$contact_days = array('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');


// legal
define('LEGAL_TEXT', '&copy; 2010-2011 Le Lab mastering All Rights Reserved<br/>Another <a href="http://www.unik-art.ca" target="_blank">www.unik-art.ca</a> creation');