<div id="view">
	<img src="<?php echo $_conf['path']['base_url']; ?>img/view-<?php echo $bodyClass; ?>.png" alt="" />
</div>