<?php
$metaTITLE['fr'] = 'Ing&eacute;nieurs';
$metaTITLE['en'] = 'Engineers';
$bodyClass = 'engineers';

include 'includes/header.php';
?>

<div class="row">
    <div class="half-box left">
        <div class="half-box-content">
            <h2>Marc Th&eacute;riault</h2>
            <h4><?php echo ENGINEER_CHIEF_MASTERING; ?></h4>
            <img src="<?php echo $_conf['path']['base_url']; ?>img/marc-photo.jpg" alt="" />
            <p>Marc Th&eacute;riault is establishing himself as one of the industry&rsquo;s most promising mastering engineers, redefining boundaries with innovative techniques and approach.  Th&eacute;riault&rsquo;s keen ability to grasp the essence of a project combined with his technical expertise allows him to develop the final creative touch for any musical genre.</p>
            <p>As Chief Engineer at LE&nbsp;LAB&nbsp;Mastering, Marc is involved in all aspects of studio design and calibration.  His Bachelor's Degree in Electrical Engineering, combined with over 20 years of experience in the audio industry is the culmination of his art as a master in audio. </p>
            <p style="clear:both">Always pushing the limits of his top of the line custom equipment to find the right sonic character for the right job, Marc&rsquo;s philosophy is to truly understand the relation between audio and emotion. With a solid reputation in live sound reinforcement, Marc understands the moment that needs to be translated to any kind of media format.</p>
        </div>
        <div class="half-box-bottom"></div>
    </div>
    
    <div class="half-box">
        <div class="half-box-content">
            <h2>Carl Talbot</h2>
            <h4><?php echo ENGINEER_MASTERING; ?></h4>
            <img src="<?php echo $_conf['path']['base_url']; ?>img/blank-photo.jpg" alt="" />
            <p>Carl Talbot, recording producer and sound engineer, is a well-established audio professional in his community.  His productions have received nominations, honours, and awards across the globe: Grammy, Juno, Felix, Gramophone Critics&rsquo; choice awards, Diapason d&rsquo;Or, and many more. His 20 years of experience have led to hundreds of albums and films. Known for his musical approach and aesthetics, he benefits from having the rare qualities of being at ease artistically and technically in many genres of music. Starting in 2008, this strong experience led to a premier position with Kent Nagano and the Orchestre Symphonique de Montr&eacute;al as sound recording engineer, and, in 2009, a new collaboration with Montreal-based state-of-the-art  mastering studio &lsquo;LE&nbsp;LAB&nbsp;Mastering&rsquo;.</p>
            <p>He is currently the leading producer at Analekta, Canada&rsquo;s largest classical label. He worked as well for Effendi Records, Justin Time Records, Sony-BMG, EMI, Virgin Classics and Radio-Canada.</p>
            <p>Talbot holds a Bachelor&lsquo;s Degree in Piano from McGill&nbsp;University and a Master&rsquo;s Degree in Sound Recording from McGill&nbsp;University.  He is a guest lecturer at the Banff Center for the Arts and at McGill&nbsp;University.</p>
        </div>
        <div class="half-box-bottom"></div>
    </div>
</div>
<div class="row">
    <div class="half-box left">
        <div class="half-box-content">
            <h2>Marc-Olivier Bouchard</h2>
            <h4><?php echo ENGINEER_MASTERING; ?></h4>
            <img src="<?php echo $_conf['path']['base_url']; ?>img/marco-photo.jpg" alt="" />
            <p>Marc-Olivier started to play violin at the early age of 9. His love for music definitely helped him find his path as a mastering engineer. Asked by Alain DeRoque to join SNB Mastering team when he was 19 years old, he received an intensive training and became one of the youngest mastering engineer who ever worked at this facility. After moving SNB to Pure Mastering, Marc-Olivier was asked to rebuild the critical monitoring with a team of professionals.</p>
            <p>With mastered gold disc such as Annie Villeneuve and IMA, he proved that his knowledge helps artists to achieve their sonic goal in this critical last step. For Marc-Olivier, it&rsquo;s more than just an audio project to master. It&rsquo;s putting breath and life into it and making sure that the vision of the artist and producer is well respected.</p>
            <p>After a few years behind the mastering console, Marc-Olivier joined LE&nbsp;LAB&nbsp;Mastering in 2010. His assurance and approach is still appreciated by the people who have been working with him in the studio. His musical background leads him to work in many musical styles with different artists such as Anne Bisson, Gregory Charles, Ima, Zachary Richard, Michel Rivard, Anodajay and many others. </p>
            <p>Follow him on twitter @MOBMastering</p>
            <p>Discography online: <a class="blue" href="http://albumcredits.com/marco.bouchard" target="_blank">http://albumcredits.com/marco.bouchard</a></p>
            <p><a class="blue" href="mailto:mob@lelabmastering.com">mob@lelabmastering.com</a></p>
        </div>
        <div class="half-box-bottom"></div>
    </div>
    
    <div class="half-box">
        <div class="half-box-content">
            <h2>Marcus</h2>
            <h4><?php echo ENGINEER_MASTERING; ?></h4>
            <img src="<?php echo $_conf['path']['base_url']; ?>img/blank-photo.jpg" alt="" />
            <p>Marcus makes records with and for other people as a mastering engineer, producer, engineer, mixer, musician, writer and arranger.
His early passion for music inspired him to play in various projects from the age of thirteen and eventually led him to study music at university.  He obtained both his Bachelor of Music in jazz performance (1997) and his Masters in Recording Engineering (2000) from McGill&nbsp;University.</p>
			<p>Based in Montreal, Marcus has worked on hundreds of diverse recording projects including:</p>
            <ul>
                <li>Arcade Fire &ldquo;The Suburbs&rdquo; - 2011 Grammy award for best album&nbsp;of&nbsp;the&nbsp;year. 2011 Brit award for best international album and best international group.</li>
                <li>The McDades &ldquo;Bloom&rdquo; - 2007 Juno award for best roots and traditional album&nbsp;of&nbsp;the&nbsp;year.</li>
                <li>Stars &ldquo;Set Yourself on Fire&rdquo; - 2005 Juno award nominee for best alternative album&nbsp;of&nbsp;the&nbsp;year.</li>
            </ul>
            <p>In addition to his recording career, Marcus is currently the main songwriter in the rock group Silver Starling (Last Gang/Universal records) and plays lead guitar in indie rock group Little Scream (Secretly Canadian records).</p>
        </div>
        <div class="half-box-bottom"></div>
    </div>
</div>

<?php
include 'includes/footer.php';
?>