<?php
$metaTITLE['fr'] = 'Studio';
$metaTITLE['en'] = 'Studio';
$bodyClass = 'studio';

include 'includes/header.php';
?>

<div class="full-box">
	<div class="full-box-top"></div>
    <div class="full-box-content">
		<h2><?php echo STUDIO_H2; ?></h2>
        <div class="column">
        	<h4><?php echo STUDIO_MONITOR; ?></h4>
            <ul>
            	<li>Focal SM8</li>
            	<li>Focal Grande Utopia Em</li>
        		<li>Focal Sub Utopia Be</li>
				<li>YBA Passion 1000</li>
				<li>Sennheiser Orpheus</li>
				<li>Sennheiser HD-600</li>
				<li>Sennheiser HD-650</li>
				<li>Grado RS-1</li>
				<li>Grace m906</li>
            </ul>
        </div>
        <div class="column">
        	<h4><?php echo STUDIO_FURNITURE; ?></h4>
            <ul>
                <li>Sterling Modular</li>
                <li>Solidtech</li>
                <li>Herman Miller</li>
                <li>HAG</li>
            </ul>
            <h4><?php echo STUDIO_TRANSPORT; ?></h4>
            <ul>
                <li>Ampex ATR-102</li>
                <li>Studer A807</li>
                <li>Oracle Delphi MK VI</li>
                <li>Tascam DV-RA1000</li>
                <li>Tascam DA-45HR</li>
            </ul>
        </div>
        <div class="column">
        	<h4><?php echo STUDIO_PROCESSOR; ?></h4>
            <ul>
                <li>Manley Labs</li>
                <li>George Massenburg Labs</li>
                <li>Shadow Hills</li>
                <li>Millenia Media</li>
                <li>D.W. Fearn</li>
                <li>Dangerous Music</li>
			</ul>

        	<h4><?php echo DIGITAL_PROCESSOR; ?></h4>
			<ul>
                <li>TC  6000 (mastering)</li>
                <li>Z-sys z-CL6</li>
                <li>Weiss EQ1-LP</li>
            </ul>
        </div>



        <div class="column">
        	<h4><?php echo STUDIO_POWER; ?></h4>
            <ul>
                <li>Isolated Transformer</li>
                <li>Isolated Ground</li>
                <li>Current Technology Power Siftor</li>
                <li>Pure/AV PF-31</li>
            </ul>
            <h4><?php echo STUDIO_ROOM; ?></h4>
                <li>20 Hz Control Room</li> 
                <li>design by Tom Hidley</li>
        </div>
        <div class="column">
        	<h4><?php echo STUDIO_CONVERTER; ?></h4>
            <ul>
                <li>Lavry Gold AD-122 96 MK III</li>
                <li>DAD AX24</li>
            </ul>
            <h4><?php echo STUDIO_DAW; ?></h4>
                <li>Sequoia  v11</li>
                <li>Protools v8 HD</li>
        </div>
    </div>
    <div class="full-box-bottom"></div>
</div>

<?php
include 'includes/footer.php';
?>