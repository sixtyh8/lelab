<?php
// login
define('LOGIN_USERNAME', 'Usager');
define('LOGIN_PASSWORD', 'Mot de passe');

// main menu
define('MAIN_MENU_HOME', 'Accueil');
define('MAIN_MENU_STUDIO', 'Studio');
define('MAIN_MENU_ENGINEERS', 'Ing&eacute;nieurs');
define('MAIN_MENU_MASTERING', 'Mastering');
define('MAIN_MENU_LAB', 'Lab');
define('MAIN_MENU_CONTACT', 'Contact');

// colonne de droite
define('RIGHT_COL_ACCESS', 'D&eacute;j&agrave; un acc&egrave;s ?');
define('RIGHT_COL_STAY_CONNECTED', 'Restez connect&eacute; !');

// studio titles
define('STUDIO_H2', '&Eacute;quipment');
define('STUDIO_MONITOR', 'Moniteur');
define('STUDIO_FURNITURE', 'Furniture');
define('STUDIO_TRANSPORT', 'Transport');
define('STUDIO_PROCESSOR', 'Processeur Analogue');
define('DIGITAL_PROCESSOR', 'Processeur Digital');
define('STUDIO_POWER', 'Alimentation');
define('STUDIO_ROOM', 'Pi&egrave;ce');
define('STUDIO_CONVERTER', 'Converter');
define('STUDIO_DAW', 'Daw');

// ing�nieurs titles
define('ENGINEER_CHIEF_MASTERING', 'Chef Ing&eacute;nieur Mastering');
define('ENGINEER_MASTERING', 'Ing&eacute;nieur Mastering');

// contact
define('CONTACT_OPENING', 'Ouverture');
define('CONTACT_LATE', 'Heures tardives');
$contact_days = array('Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim');

// legal
define('LEGAL_TEXT', '&copy; 2010-2011 Le Lab mastering tous droits r&eacute;serv&eacute;s<br/>Une cr&eacute;ation <a href="http://www.unik-art.ca" target="_blank">www.unik-art.ca</a>');