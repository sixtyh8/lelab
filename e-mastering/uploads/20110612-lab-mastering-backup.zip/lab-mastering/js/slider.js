// JavaScript Document

var offset = 920;
var speed = 800;
var slide = 1;
var slideWay = 'right';
var timer;
var timeInterval = 4000;

init();

function init(){
	$('.list').hide();
	
	$('#s' + slide).show();
	
	$('.cover').mouseover(function(){
		stopSlider();
		$(this).children('.title').show();				
	});
	$('.cover').mouseout(function(){
		startSlider();
		$(this).children('.title').hide();				
	});
	
	startSlider();
}

function startSlide(way){
	stopSlider();
	if(way == undefined) way = slideWay;
	slideWay = way;
	
	if(slideWay == undefined) alert('shit');
	
	$('#slider-prev, #slider-next').hide();
	$('#slider-prev, #slider-next').fadeIn(speed*2);
	var next = '';
	if(slideWay == 'left'){
		$('#s'+slide).animate({"left" : "-="+offset+"px"}, speed);
		
		if(slide == maxSlide) next = $('#s1');
		else next = $('#s'+(slide + 1));
		
		next.show();
		next.css('left', offset + 'px');
		next.animate({"left" : "-="+offset+"px"}, speed);
		
		if(slide == maxSlide) slide = 1;
		else slide++;
	}
	else{
		$('#s'+slide).animate({"left" : "+="+offset+"px"}, speed);
		
		if(slide == 1) next = $('#s' + maxSlide);
		else next = $('#s'+(slide - 1));
		
		next.show();
		next.css('left', '-' + offset + 'px');
		next.animate({"left" : "+="+offset+"px"}, speed);
		
		if(slide == 1) slide = maxSlide;
		else slide--;
	}
	startSlider();
}

function startSlider(){
	clearInterval(timer);
	timer = setInterval('startSlide()', timeInterval);	
}

function stopSlider(){
	clearInterval(timer);	
}