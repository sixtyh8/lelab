<?php
$metaTITLE['fr'] = 'Mastering';
$metaTITLE['en'] = 'Mastering';
$bodyClass = 'mastering';

include 'includes/header.php';
?>

<!-- Services -->
<div class="full-box">
	<div class="full-box-top"></div>
    <div class="full-box-content no-background no-minheight">
    <?php if($_conf['translation']['lang'] == 'en'){ ?>
    	<h2>Our services</h2>
        <ul>
        	<li>Mastering CD / Stems Mastering</li>
			<li>"Radio Single" Mastering</li>
			<li>Recording, Archive or Complete Catalog Remastering</li>
            <li>Audio Restoration:  Editing / Dithering / Downsampling - Upsampling</li>
            <li>Back-up or Transfer from:  DAT / Tape / CD / VINYL</li>
            <li>Digitizing: High Frequency Sampling Rate digital transfer</li>  
            <li>Analog to Digital or Digital to Analog</li>
            <li>Complete Quality Control (Freak)</li>
            <li>Tape Baking : A careful process of heating hydrolyzed tape under low heat over a long period of time to remove moisture. This makes the tape playable for a short time during which it can be re-mastered to a new tape.</li>
        </ul>
    <?php } else { ?>
    	<h2></h2>
        <p></p>
    <?php } ?>
    </div>
    <div class="full-box-bottom"></div>
</div>


<!-- Master formats -->
<div class="full-box">
	<div class="full-box-top"></div>
    <div class="full-box-content no-background no-minheight">
    <?php if($_conf['translation']['lang'] == 'en'){ ?>
    	<h2>Master Format for the replication available</h2>
        <ul>
			<li>Audio CD (Redbook Master) 
            <li>DDP Master (Yellowbook Master)</li>
            <li>BLER Error Report / PQ Listing</li>
        </ul>
        <p>* We also deliver you the files with our simple transfer service for approval purpose.</p>
    <?php } else { ?>
    	<h2></h2>
        <p></p>
    <?php } ?>
    </div>
    <div class="full-box-bottom"></div>
</div>

<!-- Format accepted -->
<div class="full-box">
	<div class="full-box-top"></div>
    <div class="full-box-content no-background no-minheight">
    <?php if($_conf['translation']['lang'] == 'en'){ ?>
    	<h2>Mastering Format Accepted</h2>
        <ul>
			<li>DATA CD or DVD: Keep the files as is original sampling rate. 24-bit of resolution is the best to work with at the Mastering.</li>
            <li>DAT - (Digital Audio Tape)</li>
            <li>Tape &frac12;&rsquo; or &frac14;&rsquo;</li>
            <li>USB Key</li>
            <li>Audio CD (Wich is not the best...)</li>
            <li>Internet transfer</li>
        </ul>
        <p>* When you are sending your files to the studio by the internet, it&rsquo;s important to make a folder with all your files and compressed the folder with a software (Winzip or Winrar) to preserve the integrity of the data.</p>
        <p><strong>At The End...</strong></p>
		<p>We can provide you an Audio-CD Reference for approval wich is the same of the Master for the replication plant. 
Also, we can deliver all the wave files by the internet for the approval of your project.</p>
    <?php } else { ?>
    	<h2></h2>
        <p></p>
    <?php } ?>
    </div>
    <div class="full-box-bottom"></div>
</div>
<?php
include 'includes/footer.php';
?>